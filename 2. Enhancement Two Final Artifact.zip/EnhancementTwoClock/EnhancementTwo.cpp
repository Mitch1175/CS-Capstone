/*
Mitchel Dauk
02/06/2024
CS-210-R3198
Programming Languages
Project One

**REVISED**
11/20/2024
CS-499-18323
Computer Science Capstone
Enhancement Two
*/

// Adds header files
#include <iostream>													// Allows data to be displayed
#include <iomanip>													// Allows manipulation of output streams
#include <cstdlib>													// Allows random numbers

using namespace std;												// User names are from the standard library

// Creates a function that calls hour, minute, second, and the 12 hour clock
void clockT(int& hour, int& minute, int& second, int& hourT) {

	bool quit = false;												// Allows the program to quit if called
	int choice;														// initializes integer choice

	while (!quit) {													// Creates a loop when quit is not selected

		// Box One and Two. Top Line
		cout << setfill('*') << setw(26) << "";						// Fills 26 spaces with *
		cout << setfill(' ') << setw(6) << "";					    // Fills 6 spaces next to *
		cout << setfill('*') << setw(26) << "" << endl;				// Fills 26 spaces with *

		// Second Line (Clock Names)
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(6) << "";						// Fills 6 spaces next to *
		cout << "12-Hour Clock";									// Prints 12-Hour Clock
		cout << setfill(' ') << setw(5) << "";						// Fills 5 spaces next to printed line
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(6) << "";						// Fills 6 spaces next to *
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(6) << "";						// Fills 6 spaces next to *
		cout << "24-Hour Clock";									// Prints 24-Hour Clock
		cout << setfill(' ') << setw(5) << "";						// Fills 5 spaces next to printed line
		cout << setfill('*') << setw(1) << "" << endl;				// Fills 1 space with *

		// Third Line (Clock Display)
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(8) << "";						// Fills 8 spaces next to *
		cout << setfill('0') << setw(2) << hourT << ":";			// Fills a 0 in if it is a single digit
		cout << setfill('0') << setw(2) << minute << ":";			// Fills a 0 in if it is a single digit
		cout << setfill('0') << setw(2) << second;					// Fills a 0 in if it is a single digit

		// Initializes AM or PM and prints it after the time
		if (hour > 11) {
			cout << " PM";
		}
		else {
			cout << " AM";
		}

		cout << setfill(' ') << setw(5) << "";						// Fills 5 spaces next to printed line
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(6) << "";						// Fills 6 spaces next to *
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(8) << "";						// Fills 8 spaces next to *
		cout << setfill('0') << setw(2) << hour << ":";				// Fills a 0 in if it is a single digit
		cout << setfill('0') << setw(2) << minute << ":";			// Fills a 0 in if it is a single digit
		cout << setfill('0') << setw(2) << second;					// Fills a 0 in if it is a single digit
		cout << setfill(' ') << setw(8) << "";						// Fills 8 spaces next to *
		cout << setfill('*') << setw(1) << "" << endl;				// Fills 1 space with *

		// Bottom Line
		cout << setfill('*') << setw(26) << "";						// Fills 26 spaces with *
		cout << setfill(' ') << setw(6) << "";						// Fills 6 spaces next to *
		cout << setfill('*') << setw(26) << "" << endl;				// Fills 26 spaces with *
		
		//Box Three
		cout << setfill(' ') << setw(16) << "";						// Fills 16 spaces next to *
		cout << setfill('*') << setw(26) << "" << endl;				// Fills 26 spaces with *

		cout << setfill(' ') << setw(16) << "";						// Fills 16 spaces next to *
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(1) << "";						// Fills 1 space next to *
		cout << "1 - Add One Hour";									// Prints Add One Hour
		cout << setfill(' ') << setw(7) << "";						// Fills 7 spaces next to *
		cout << setfill('*') << setw(1) << "" << endl;				// Fills 1 space with *

		cout << setfill(' ') << setw(16) << "";						// Fills 16 spaces next to *
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(1) << "";						// Fills 1 space next to *
		cout << "2 - Add One Minute";								// Prints Add One Minute
		cout << setfill(' ') << setw(5) << "";						// Fills 5 spaces next to *
		cout << setfill('*') << setw(1) << "" << endl;				// Fills 1 space with *

		cout << setfill(' ') << setw(16) << "";						// Fills 16 spaces next to *
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(1) << "";						// Fills 1 space next to *
		cout << "3 - Add One Second";								// Prints Add One Second
		cout << setfill(' ') << setw(5) << "";						// Fills 5 spaces next to *
		cout << setfill('*') << setw(1) << "" << endl;				// Fills 1 space with *

		cout << setfill(' ') << setw(16) << "";						// Fills 16 spaces next to *
		cout << setfill('*') << setw(1) << "";						// Fills 1 space with *
		cout << setfill(' ') << setw(1) << "";						// Fills 1 space next to *
		cout << "4 - Exit Program";									// Prints Exit Program
		cout << setfill(' ') << setw(7) << "";						// Fills 7 spaces next to *
		cout << setfill('*') << setw(1) << "" << endl;				// Fills 1 space with *

		cout << setfill(' ') << setw(16) << "";						// Fills 16 spaces next to *
		cout << setfill('*') << setw(26) << "" << endl;				// Fills 26 spaces with *

		cout << endl << "Please make a selection" << endl;			// Prints Please make a selection

		cin >> choice;      // Allows the user to pick a number from the switch case

		switch (choice) {   // Allows the user to pick a number

		case 1:
			hour = (hour + 1) % 24;								    // Adds 1 hour if 1 is picked (24-hour clock)
			hourT = (hourT + 1) % 13;						        // Adds 1 hour if 1 is picked (12-hour clock)
			cout << "One Hour Added" << endl;					    // Prints if hour was added
			break;												    // End case

		case 2:
			minute = (minute + 1) % 60;							    // Adds 1 minute if 2 is picked
			cout << "One Minute Added" << endl;						// Prints if minute was added
			if (minute == 00) {									    // If a minute is added to 59, it will add 1 hour
				hour = hour + 1;									// One hour will be added
				hourT = hourT + 1;									// One hour will be added
			}
			else {
				minute == minute;									// Otherwise the minute will remain the same
			}
			break;													// End case

		case 3:
			second = (second + 1) % 60;								// Adds 1 second if 3 is picked
			cout << "One Second Added" << endl;						// Prints if second was added
			if (second == 00) {										// If a second is added to 59, it will add 1 minute
				minute = minute + 1;								// One minute will be added
			}
			else {
				second == second;									// Otherwise the second will remain the same
			}
			break;													// End case

		case 4:
			cout << "Goodbye" << endl;								// Print Goodbye
			quit = true;											// Quits program
			break;													// End case

		default:													// Tells the user what they picked is invalid and allows a new number
			cout << "Invalid. Please select a number between 1 and 4." << endl;
			break;
		}

		// Makes sure the clock continues from 12 to 1 and not 12 to 0
		if (hourT == 0) {
			hourT = 01;
		}
		else {
			(hourT = hourT);
		}

		// Makes sure minutes do not equal 60 when seconds pass 59
		if (minute == 60) {
			minute = 00;
		}
		else {
			minute = minute;
		}

		// If the second and the minute pass 59, 1 hour will be added
		if ((second == 00) && (minute == 00)) {
			hour = hour + 1;
			hourT = hourT + 1;
		}
		else {
			hour = hour;
		}
	}
}

int main() {

	// Initiates random time to be made
	srand(time(0));
	
	int minute = rand() % 60;     // Gives random time within parameters of 0-59
	int second = rand() % 60;     // Gives random time within parameters of 0-59
	int hourT = rand() % 12 + 1;  // Gives random time within parameters of 1-12
	int hour = hourT + 12;        // Adds 12 hours to 12-hour clock

	// Added hour to not randomize to 24
	if (hour == 24) {
		hour = 0;
	}

	// Runs the function clockT
	clockT(hour, minute, second, hourT);

	return 0;
}