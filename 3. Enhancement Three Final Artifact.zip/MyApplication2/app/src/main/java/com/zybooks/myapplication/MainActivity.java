package com.zybooks.myapplication;

import static androidx.constraintlayout.motion.widget.TransitionBuilder.validate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;

// Main class used
public class MainActivity extends AppCompatActivity {

    // Iterates the names for buttons, edit, and text
    private Button signIn;
    private Button createNewLogin;
    private EditText nameText;
    private EditText passwordText;
    private TextView textGreeting;

    private Button ld;
    ImageView imageView;
    ImageView imageView2;

    // Initiates initial username and password
    private String userName = "MDAUK";
    private String password = "SNHU123";

    // boolean to show if true or false initially
    boolean isValid = false;

    // Class to initially create content
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Connects names to id names
        signIn = findViewById(R.id.buttonSignIn);
        nameText = findViewById(R.id.nameText);
        passwordText = findViewById(R.id.passwordText);

        // Creates a listener for a button
        signIn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Allows name and password
                String userName = nameText.getText().toString();
                String password = passwordText.getText().toString();

                // Declares if edit text is null or incorrect
                if (userName.isEmpty() || password.isEmpty()) {
                    textGreeting.setText("Incorrect username or password");
                } else {
                    isValid = validate(userName, password);

                    if (!isValid) {
                        textGreeting.setText("Incorrect username or password");
                    } else {
                        // Takes user to next screen
                        Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                        startActivity(intent);
                    }
                }
            }


        });

        // creates both light and dark modes by using a button

        imageView = findViewById(R.id.imageView2);

        ld = findViewById(R.id.buttonDark);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.black);

            }
        });

        imageView2 = findViewById(R.id.imageView3);

        ld = findViewById(R.id.buttonLight);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.gray);

            }
        });

        // Connects names to id names
        createNewLogin = findViewById(R.id.buttonCreateNewLogin);
        textGreeting = findViewById(R.id.textGreeting);
        createNewLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Allows name and password
               String userName = nameText.getText().toString();
               String password = passwordText.getText().toString();

                // Declares if edit text is null or incorrect
                if (userName.isEmpty() || password.isEmpty()) {
                    textGreeting.setText("Please enter a valid username and password");
                } else {
                    // Takes user to next screen with created account
                    Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                    startActivity(intent);
                    textGreeting.setText("New account created");
                }
            }
        });

    }

    // Verifies username and password is correct
    private boolean validate(String userName, String password) {
        if (userName.equals(userName) && password.equals(password)) {
            return true;
        }
        return false;
    }
}