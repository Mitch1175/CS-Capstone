package com.zybooks.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity3 extends AppCompatActivity {

    // Iterates the names for buttons, edit, and text
    private Button settings;
    private Button add;
    private Button clearList;
    private EditText nameText;

    private Button ld;
    ImageView imageView;
    ImageView imageView2;

    private ListView listView;
    private ArrayList<String> arrayList;
    private ArrayAdapter<String> adapter;

    int count = 1;

    private Button plus;
    private Button minus;
    private TextView amount;

    private Button plus2;
    private Button minus2;
    private TextView amount2;

    private Button plus3;
    private Button minus3;
    private TextView amount3;

    private Button plus4;
    private Button minus4;
    private TextView amount4;

    private Button plus5;
    private Button minus5;
    private TextView amount5;

    private Button plus6;
    private Button minus6;
    private TextView amount6;

    // Class to initially create content
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main3);

        // Connects names to id names and creates button
        settings = findViewById(R.id.buttonSettings);
        settings.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // Takes user to next screen
                Intent intent=new Intent(MainActivity3.this,MainActivity2.class);
                startActivity(intent);
            }
        });

        // Connects names to id names
        nameText = findViewById(R.id.ItemText);
        add = findViewById(R.id.buttonAddItem);
        listView = findViewById(R.id.ListInventory);

        // Creates list with adapter
        arrayList = new ArrayList<>();
        adapter = new ArrayAdapter<String> (getApplicationContext(), android.R.layout.simple_list_item_1, arrayList);

        listView.setAdapter(adapter);

        // Creates a listener for a button
        add.setOnClickListener(new View.OnClickListener() {

            // Allows the list to be added from the users input
            @Override
            public void onClick(View view) {
                   arrayList.add(nameText.getText().toString());


            adapter.notifyDataSetChanged();


            }

        });

        // Connects names to id names and creates button
        clearList = findViewById(R.id.buttonClear);
        clearList.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                arrayList.clear();
                adapter.notifyDataSetChanged();
            }
        });


        // Connects names to id names
        amount = findViewById(R.id.Quantity1);
        plus = findViewById(R.id.buttonPlus);
        minus = findViewById(R.id.buttonMinus);

        // Creates plus button at default 1
        plus.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                count++;
                amount.setText("" + count);
            }
        });
        // Creates minus button at default 1
        minus.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(count <= 0) count = 1;
                else count--;
                amount.setText("" + count);
            }
        });

        // Connects names to id names
        amount2 = findViewById(R.id.Quantity2);
        plus2 = findViewById(R.id.buttonPlus2);
        minus2 = findViewById(R.id.buttonMinus2);

        // Creates plus button at default 1
        plus2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                count++;
                amount2.setText("" + count);
            }
        });
        // Creates minus button at default 1
        minus2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(count <= 0) count = 1;
                else count--;
                amount2.setText("" + count);
            }
        });

        // Connects names to id names
        amount3 = findViewById(R.id.Quantity3);
        plus3 = findViewById(R.id.buttonPlus3);
        minus3 = findViewById(R.id.buttonMinus3);

        // Creates plus button at default 1
        plus3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                count++;
                amount3.setText("" + count);
            }
        });
        // Creates minus button at default 1
        minus3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(count <= 0) count = 1;
                else count--;
                amount3.setText("" + count);
            }
        });

        // Connects names to id names
        amount4 = findViewById(R.id.Quantity4);
        plus4 = findViewById(R.id.buttonPlus4);
        minus4 = findViewById(R.id.buttonMinus4);

        // Creates plus button at default 1
        plus4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                count++;
                amount4.setText("" + count);
            }
        });
        // Creates minus button at default 1
        minus4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(count <= 0) count = 1;
                else count--;
                amount4.setText("" + count);
            }
        });

        // Connects names to id names
        amount5 = findViewById(R.id.Quantity5);
        plus5 = findViewById(R.id.buttonPlus5);
        minus5 = findViewById(R.id.buttonMinus5);

        // Creates plus button at default 1
        plus5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                count++;
                amount5.setText("" + count);
            }
        });
        // Creates minus button at default 1
        minus5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(count <= 0) count = 1;
                else count--;
                amount5.setText("" + count);
            }
        });

        // Connects names to id names
        amount6 = findViewById(R.id.Quantity6);
        plus6 = findViewById(R.id.buttonPlus6);
        minus6 = findViewById(R.id.buttonMinus6);

        // Creates plus button at default 1
        plus6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                count++;
                amount6.setText("" + count);
            }
        });
        // Creates minus button at default 1
        minus6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(count <= 0) count = 1;
                else count--;
                amount6.setText("" + count);
            }
        });

        // creates both light and dark modes by using a button

        imageView = findViewById(R.id.imageView2);

        ld = findViewById(R.id.buttonDark);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.black);

            }
        });

        imageView2 = findViewById(R.id.imageView3);

        ld = findViewById(R.id.buttonLight);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.gray);

            }
        });

    }
}
