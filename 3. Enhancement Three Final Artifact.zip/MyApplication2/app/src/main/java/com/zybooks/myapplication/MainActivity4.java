package com.zybooks.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;


public class MainActivity4 extends AppCompatActivity {

    // Iterates the names for buttons, edit, and text
    private Button changePhoto;
    private Button changePassword;
    private Button updateBio;
    private Button clear;
    private Button back2;
    private Button searchButton;
    private EditText editBio;
    private TextView seeBio;

    // buttons for light and dark mode
    private Button ld;
    ImageView imageView;
    ImageView imageView2;

    // bio view
    private ListView listView;
    private ArrayList<String> arrayList;
    private ArrayAdapter<String> adapter;



    // Class to initially create content
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main4);

        // Connects names to id names and creates button
        back2 = findViewById(R.id.buttonBack2);
        back2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // Takes user to next screen
                Intent intent = new Intent(MainActivity4.this, MainActivity2.class);
                startActivity(intent);
            }
        });

            // Connects names to id names and creates button
            searchButton = findViewById(R.id.searchB);
            searchButton.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {

                    // Takes user to next screen
                    Intent intent = new Intent(MainActivity4.this, MainActivity6.class);
                    startActivity(intent);
                }
            });

        // Connects names to id names
        editBio = findViewById(R.id.bioText);
        updateBio = findViewById(R.id.buttonUpdateBio);
        listView = findViewById(R.id.bio);

        // Creates list with adapter
        arrayList = new ArrayList<>();
        adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList);

        listView.setAdapter(adapter);

        // Creates a listener for a button
        updateBio.setOnClickListener(new View.OnClickListener() {

            // Allows the list to be added from the users input
            @Override
            public void onClick(View view) {
                arrayList.add(editBio.getText().toString());

                adapter.notifyDataSetChanged();

                editBio.setText(" ");  // Clears edit line
            }

        });

        // Connects names to id names and creates button
        clear = findViewById(R.id.buttonClear);
        clear.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                arrayList.clear();
                adapter.notifyDataSetChanged();
            }
        });

        // creates both light and dark modes by using a button

        imageView = findViewById(R.id.imageView2);

        ld = findViewById(R.id.buttonDark);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.black);

            }
        });

        imageView2 = findViewById(R.id.imageView3);

        ld = findViewById(R.id.buttonLight);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.gray);

            }
        });

    }
}