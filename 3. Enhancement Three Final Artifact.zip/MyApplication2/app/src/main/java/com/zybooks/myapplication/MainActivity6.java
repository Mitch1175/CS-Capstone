package com.zybooks.myapplication;

import static androidx.constraintlayout.widget.Constraints.TAG;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;


public class MainActivity6 extends AppCompatActivity {

    // buttons for light and dark mode
    private Button ld;
    ImageView imageView;
    ImageView imageView2;

    private Button backButton;
    private ListView listView;
    private ArrayList<String> userName;
    private ArrayAdapter<String> adapter;

    private EditText nameText;
    private String[] items;

    // Class to initially create content
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main6);

        // Database
        listView = (ListView) findViewById(R.id.usernameList);
        nameText = (EditText) findViewById(R.id.nameText);
        items = new String[] {
                "Alpha",
                "Bravo",
                "Charlie",
                "Delta",
                "Echo",
                "Foxtrot",
                "Golf",
                "Hotel",
                "India",
                "Juliet",
                "Kilo",
                "Lima",
                "Mike",
                "November",
                "Oscar",
                "Papa",
                "Quebec",
                "Romeo",
                "Sierra",
                "Tango",
                "Uniform",
                "Victor",
                "Whisky",
                "Xray",
                "Yankee",
                "Zulu",

                "AlphaDog22",
                "BravoMan34",
                "CharlieHoop09",
                "DeltaFlag34",
                "EchoCat11",
                "Foxtrot33",
                "GolfKart39",
                "HotelCali22",
                "IndianaJones67",
                "JulietStar00",
                "KiloFan62",
                "LimaBean38",
                "MikeStar44",
                "NovemberTime03",
                "OscarGrouch43",
                "PapaS30",
                "QuebecQ47",
                "RomeoFan29",
                "SierraCan40",
                "TangoToday78",
                "UniformTag93",
                "VictorViking74",
                "WhiskyCup62",
                "XrayMach13",
                "YankeeDoodle95",
                "ZuluHulu66",

                "AlphaMan46",
                "BravoDog45",
                "CharlieKart88",
                "DeltaLime92",
                "EchoParts52",
                "FoxtrotHeart50",
                "GolfTart90",
                "HotelElevator84",
                "IndiaTall13",
                "JulietStrong66",
                "KiloMilo23",
                "LimaTeen74",
                "MikeTrek82",
                "NovemberLeaf98",
                "OscarTime60",
                "PapaHap56",
                "QuebecQueue83",
                "RomeoRomeo21",
                "SierraBottle53",
                "TangoTime87",
                "UniformBadge12",
                "VictorUnion86",
                "WhiskyFriend68",
                "XrayBone99",
                "YankeeGirl22",
                "ZuluFan45",

                "AlphaDog77",
                "BravoMan45",
                "CharlieHoop48",
                "DeltaFlag92",
                "EchoCat16",
                "Foxtrot93",
                "GolfKart04",
                "HotelCali14",
                "IndianaJones73",
                "JulietStar73",
                "KiloFan38",
                "LimaBean21",
                "MikeStar60",
                "NovemberTime63",
                "OscarGrouch69",
                "PapaS33",
                "QuebecQ79",
                "RomeoFan21",
                "SierraCan26",
                "TangoToday68",
                "UniformTag48",
                "VictorViking28",
                "WhiskyCup48",
                "XrayMach17",
                "YankeeDoodle93",
                "ZuluHulu37",

                "AlphaMan88",
                "BravoDog54",
                "CharlieKart36",
                "DeltaLime87",
                "EchoParts22",
                "FoxtrotHeart00",
                "GolfTart65",
                "HotelElevator23",
                "IndiaTall65",
                "JulietStrong12",
                "KiloMilo67",
                "LimaTeen95",
                "MikeTrek93",
                "NovemberLeaf88",
                "OscarTime34",
                "PapaHap78",
                "QuebecQueue04",
                "RomeoRomeo24",
                "SierraBottle65",
                "TangoTime27",
                "UniformBadge17",
                "VictorUnion18",
                "WhiskyFriend28",
                "XrayBone34",
                "YankeeGirl12",
                "ZuluFan76",


        };

        // Adds names to the list
        userName = new ArrayList<>(Arrays.asList(items));
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, userName);
        listView.setTextFilterEnabled(true);
        listView.setAdapter(adapter);

        // Allows the user to search for usernames
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged (CharSequence charSequence, int i, int il, int i2) {

            }

            @Override
            public void onTextChanged (CharSequence charSequence, int i, int il, int i2) {
                MainActivity6.this.adapter.getFilter().filter(charSequence);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged (Editable editable) {

            }
        });




        // Connects names to id names and creates button
        backButton = findViewById(R.id.backB);
        backButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // Takes user to next screen
                Intent intent = new Intent(MainActivity6.this, MainActivity4.class);
                startActivity(intent);
            }
        });

        imageView = findViewById(R.id.imageView2);

        ld = findViewById(R.id.buttonDark);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.black);

            }
        });

        imageView2 = findViewById(R.id.imageView3);

        ld = findViewById(R.id.buttonLight);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.gray);

            }
        });

    }
}