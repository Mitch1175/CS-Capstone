package com.zybooks.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    // Names the buttons
    private Button back;
    private Button logout;
    private Button profile;

    private Button ld;
    ImageView imageView;
    ImageView imageView2;

    // Class to initially create content
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        // Connects names to id names and creates button
        back = findViewById(R.id.buttonBack);
        back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // Takes user to next screen
                Intent intent=new Intent(MainActivity2.this,MainActivity3.class);
                startActivity(intent);
            }
        });

        // Connects names to id names and creates button
        logout = findViewById(R.id.buttonLogout);
        logout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // Takes user to next screen
                Intent intent=new Intent(MainActivity2.this,MainActivity.class);
                startActivity(intent);
            }
        });

        // Connects names to id names and creates button
        profile = findViewById(R.id.buttonProfile);
        profile.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // Takes user to next screen
                Intent intent=new Intent(MainActivity2.this, MainActivity4.class);
                startActivity(intent);
            }
        });

        // creates both light and dark modes by using a button

        imageView = findViewById(R.id.imageView2);

        ld = findViewById(R.id.buttonDark);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.black);

            }
        });

        imageView2 = findViewById(R.id.imageView3);

        ld = findViewById(R.id.buttonLight);
        ld.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.gray);

            }
        });

    }
}